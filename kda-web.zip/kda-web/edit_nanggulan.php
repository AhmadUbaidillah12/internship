<?php
// include database connection file
include_once("config.php");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{	
    $id = $_POST['id'];
    
    $Wilayah=$_POST['Wilayah'];
    $Agama=$_POST['Agama'];
    $L=$_POST['L'];
    $P=$_POST['P'];
    $Total=$_POST['Total'];

    // update user data
    $result = mysqli_query($mysqli, "UPDATE kab_kulonprogo_nanggulan SET Wilayah='$Wilayah',Agama='$Agama',L='$L',P='$P',Total='$Total' WHERE id=$id");

    // Redirect to homepage to display updated user in list
    header("Location: nanggulan.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];
 
// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM kab_kulonprogo_nanggulan WHERE id=$id");
 
while($user_data = mysqli_fetch_array($result))
{
    $id = $user_data['id'];
    $Wilayah = $user_data['Wilayah'];
    $Agama = $user_data['Agama'];
    $L = $user_data['L'];
    $P = $user_data['P'];
    $Total = $user_data['Total'];

}
?>
<html>
    <link rel="stylesheet" href="edit_style.css">
<head>	
    <title>Edit Data</title>
</head>
<body>

    <div class="container">
    <div class="tulisan-update">
        <h3>Update Data</h3></div>
	<form name="update_user" method="post" action="edit_nanggulan.php" >
		<div class="field" tabindex="1">
			<label for="Wilayah">
				<i class="far fa-user"></i>Wilayah
			</label>
			<input name="Wilayah" type="text"   value=<?php echo $Wilayah;?>>
		</div>
		<div class="field" tabindex="2">
			<label for="Agama">
				<i class="far fa-envelope"></i>Agama
			</label>
			<input name="Agama" type="text"  value=<?php echo $Agama;?>></input>
		</div>
    <div class="field" tabindex="3">
			<label for="L">
				<i class="far fa-envelope"></i>Laki-Laki
			</label>
			<input name="L" type="text"   value=<?php echo $L;?>></input>
		</div>
    <div class="field" tabindex="4">
			<label for="P">
				<i class="far fa-envelope"></i>Perempuan
			</label>
			<input name="P" type="text"   value=<?php echo $P;?>></input>
		</div>
    <div class="field" tabindex="5">
			<label for="Total">
				<i class="far fa-envelope"></i>Total
			</label>
			<input name="Total" type="text"   value=<?php echo $Total;?>></input>
		</div>
        <input type="hidden" name="id" value= <?php echo $_GET ['id'];?>> </input>
		<button type="submit" name="update" value="update" >Update Data</button>
			<span>
			<a href="nanggulan.php">Back Home &nbsp<i class="fas fa-long-arrow-alt-right" ></a></i>
			</span>
		</div>
	</form>
</div>
</body>
</html>