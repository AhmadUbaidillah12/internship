<?php
// include database connection file
include_once("config_ibadah.php");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{	
    $id = $_POST['id'];
    
    $Nama_Rumah_Ibadah=$_POST['Nama_Rumah_Ibadah'];
    $Jenis=$_POST['Jenis'];
    $Alamat=$_POST['Alamat'];
    $Kab=$_POST['Kab'];

    // update user data
    $result = mysqli_query($mysqli, "UPDATE kota_yogyakarta_rumah_ibadah_kristen SET  Nama_Rumah_Ibadah='$Nama_Rumah_Ibadah',Jenis='$Jenis',Alamat='$Alamat',Kab='$Kab' WHERE id=$id");

    // Redirect to homepage to display updated user in list
    header("Location: khonghucu.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$id = $_GET['id'];
 
// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM kota_yogyakarta_rumah_ibadah_kristen WHERE id=$id");
 
while($user_data = mysqli_fetch_array($result))
{
    $id = $user_data['id'];
    $Nama_Rumah_Ibadah = $user_data['Nama_Rumah_Ibadah'];
    $Jenis = $user_data['Jenis'];
    $Alamat = $user_data['Alamat'];
    $Kab = $user_data['Kab'];

}
?>
<html>
    <link rel="stylesheet" href="edit_style.css">
<head>	
    <title>Edit Data</title>
</head>
<body>

    <div class="container">
	<form name="update_user" method="post" action="edit_yk_kristen.php" >
		<div class="field" tabindex="1">
			<label for="Nama_Rumah_Ibadah">
				<i class="far fa-user"></i>Nama Rumah Ibadah
			</label>
			<input name="Nama_Rumah_Ibadah" type="text"   value=<?php echo $Nama_Rumah_Ibadah;?>>
		</div>
		<div class="field" tabindex="2">
			<label for="Jenis">
				<i class="far fa-envelope"></i>Jenis
			</label>
			<input name="Jenis" type="text"  value=<?php echo $Jenis;?>></input>
		</div>
    <div class="field" tabindex="3">
			<label for="Alamat">
				<i class="far fa-envelope"></i>Alamat
			</label>
			<input name="Alamat" type="text"   value=<?php echo $Alamat;?>></input>
		</div>
    <div class="field" tabindex="4">
			<label for="Kab">
				<i class="far fa-envelope"></i>Kabupaten
			</label>
			<input name="Kab" type="text"   value=<?php echo $Kab;?>></input>
		</div>
        <input type="hidden" name="id" value= <?php echo $_GET ['id'];?>> </input>
		<button type="submit" name="update" value="update" >Update Data</button>
			<span>
			<a href="kab_yogyakarta_kristen.php">Back Home &nbsp<i class="fas fa-long-arrow-alt-right" ></a></i>
			</span>
		</div>
	</form>
</div>
</body>
</html>