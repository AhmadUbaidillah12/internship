<?php
// Create database connection using config file
include_once("config.php");

// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM kab_gunungkidul_karangmojo ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>KDA-Kemenag Dalam Angka</title>
  <link rel='stylesheet' href='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'><link rel="stylesheet" href="./style.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
  <script src="script.js"></script>

</head>
<body>

<!-- partial:index.partial.html -->
<aside class="sidebar">
  <div id="leftside-navigation" class="nano">
    <ul class="nano-content">
      <li>
      <a href="umat.php"><i class="fa fa-map-marker"></i><span>Provinsi DIY</span></a>
      </li>

      <li class="sub-menu">
        <a href="kota_yogyakarta.php"><i class="fa fa-map-marker"></i><span>KOTA YOGYAKARTA</span><i class="arrow fa fa-angle-right pull-right"></i></a>
      </li>

      <li class="sub-menu">
        <a href="kab_sleman.php" ><i class="fa fa-map-marker"></i><span>KABUPATEN SLEMAN</span><i class="arrow fa fa-angle-right pull-right"></i></a>
      </li>

      <li class="sub-menu">
        <a href="kab_bantul.php"><i class="fa fa-map-marker"></i><span>KABUPATEN BANTUL</span><i class="arrow fa fa-angle-right pull-right"></i></a>
        
      </li>
      <li class="sub-menu">
        <a href="kab_kulonprogo.php"><i class="fa fa-map-marker"></i><span>KABUPATEN KULONPROGO</span><i class="arrow fa fa-angle-right pull-right"></i></a>
    
      </li>
      <li class="sub-menu">
        <a href="kab_gunungkidul.php"><i class="fa fa-map-marker"></i><span>KABUPATEN GUNUNGKIDUL</span><i class="arrow fa fa-angle-right pull-right"></i></a>
        
      </li>
      <li class="back">
      <a class="btn-back"><i class="gg-arrow-left-o" style="margin-right:8px; margin-left:-8px"></i><span onclick="goBack()">Kembali</span></a>
      <script>
      function goBack() {
        window.history.back();
      }
      </script>
      </li>
      <li>
      <a href="index.html" class="btn-back"><i class="gg-home-alt" style="margin-right:8px; margin-left:-8px"></i><span>Ke Halaman Utama</span></a>
      </li>
  </div>
</aside>

</div>
<article>
   
<html>
<body>
<div class="bbody" >
<h2>Kecamatan Karangmojo</h2>
<h6>Digitalisasi Data Penduduk Agama Non Muslim</h6>
<div class="container">
<div class="content">

<table width='100%' border=30 style="border-color:#497174">

<tr>
<th style="background-color:#A3D2CA; color:#000">Nomor</th>
<th style="background-color:#A3D2CA; color:#000">Wilayah</th> 
<th style="background-color:#A3D2CA; color:#000">Agama</th> 
<th style="background-color:#A3D2CA; color:#000">Laki-laki</th> 
<th style="background-color:#A3D2CA; color:#000">Perempuan</th>
<th style="background-color:#A3D2CA; color:#000">Total</th>
<th style="background-color:#A3D2CA; color:#000">Option</th>
</tr>

<?php
while($user_data = mysqli_fetch_array($result)) {         
  echo "<tr>";
  echo "<td>".$user_data['id']."</td>";
  echo "<td>".$user_data['Wilayah']."</td>";
  echo "<td>".$user_data['Agama']."</td>";
  echo "<td>".$user_data['L']."</td>"; 
  echo "<td>".$user_data['P']."</td>";
  echo "<td>".$user_data['Total']."</td>";   
  echo "<td><a href='edit_karangmojo.php?id=$user_data[id]' >Edit</a>&nbsp  &nbsp|&nbsp&nbsp <a href='delete_karangmojo.php?id=$user_data[id]'>Delete</a></td></tr>";        
}
?>
</table>     
  </div>
</div>
<a class="face-button" href="file_csv/Kab-gunungkidul/karangmojo.csv" download>

  <div class="face-primary">
  <span class="icon fa fa-cloud"></span>
    Unduh File
  </div>
  
  <div class="face-secondary">
    <span class="icon fa fa-hdd-o"></span>
    Unduh 
  </div>

</a>
<!--<button type="submit" id="download" ><a href="file_csv/semester2.csv" download>Unduh File</a></button>-->
</div>
</body>
</html>
<!-- partial -->
  <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script><script  src="./script.js"></script>

</body>
</html>
