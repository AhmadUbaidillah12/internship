# Accordion Menu

A Pen created on CodePen.io. Original URL: [https://codepen.io/maggiben/pen/bGpzPj](https://codepen.io/maggiben/pen/bGpzPj).

Accordion menu